<?php
$vt_sunucu="sql202.epizy.com";
$vt_kullanici="epiz_31839494";
$vt_sifre="CrVzXKSf4kF";
$vt_adi="epiz_31839494_akkurtyazilim";

$baglan=mysqli_connect($vt_sunucu, $vt_kullanici, $vt_sifre, $vt_adi);

if(!$baglan)
{
    die("Veritabanı Bağlantı İşlemi Başarısız".mysqli_connect_error());
}

?>