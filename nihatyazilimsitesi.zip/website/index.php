<!DOCTYPE html>
<html lang="tr">
    <head>
        <meta charset="UTF-8">
        <title>Anasayfa | AKKURT YAZILIM</title>
        <link  rel="stylesheet" href="css/style.css">       
        <script src="https://kit.fontawesome.com/0f935e1b3a.js" >
        crossorigin="anonymous"></script>
        <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300&display=swap" rel="stylesheet">
<link rel="stylesheet" href="owl/owl.carousel.min">
<link rel="stylesheet" href="owl/owl.theme.default.min">

    </head>
    <body>
        <section id="menu">
            <div id="logo">AKKURT YAZILIM</div>
            <nav>
<a href=""><i class="fa-solid fa-house ikon"></i>Anasayfa</a>
<a href=""><i class="fa-solid fa-info ikon"></i>Hakkımızda</a> 
<a href=""><i class="fa-solid fa-user-graduate ikon"></i>Eğitimler</a> 
<a href=""><i class="fa-solid fa-people-group ikon"></i>Ekip</a> 
<a href=""><i class="fa-solid fa-map-pin ikon"></i>İletişim</a> 
            </nav>
        </section>
        <section id="anasayfa">
            <div id="black">
            </div>
            <div id="içerik">
                <h2>BT ÇÖZÜMLERİ İLE HAYATA DEĞER KATIYORUZ</h2>
                <hr width=300 ,align=left>
                <p>
                   Web Tasarımı, Veritabanı Uygulamaları, Bulut Bilişim alanlarında ve ücretsiz kurslarımızla sizlere en uygun sonucu buluyoruz.
                </p>
            </div>
        </section>
        <section id="hakkimizda">
            <h3>HAKKIMIZDA</h3>
            <div class="container">
                <div id="sol">
                    <h5 id="h5sol">Teknolojide ilklerin yaratıcısı AKKURT Holding bünyesinde faaliyet gösteren şirketimiz, 2010 yılında kuruldu.
                         Bugün, 15 hizmet noktası ve 300’ü aşkın çalışanımızla bilgi ve iletişim teknolojileri pazarının önde gelen sistem entegrasyon ve saha hizmetleri firmasıyız.</h5>
                </div>
                <div id="sag">
                    <span>B</span>
                    <p id="psag">
                    ilgi ve iletişim teknolojileri sektörüne yön veren lider, uluslararası üretici ve çözüm sağlayıcı firmalar ile iş ortaklıklarımız 
                    bulunuyor. Sistem entegratörlüğü alanındaki uzmanlığımızı yerinde kurulum, bakım ve destek hizmetleri yetkinliklerimiz ile
                    birleştirerek ve ülke genelindeki yaygın saha gücümüzü kullanarak, tüm IT hizmetlerini yüksek müşteri memnuniyeti sağlayarak sunabilen bir organizasyona sahibiz.
                    Sahip olduğumuz teknoloji bilgisi, alan uzmanlığı ve proje deneyimi ile teknolojiyi doğru yöneterek,
                     müşterilerimizin bütçe, zaman ve insan kaynağını en etkin şekilde yönetebilmesine ve BT yatırımları ile değer yaratabilmesine yardımcı oluyoruz.
                    </p>
                </div>
                <img src="img/about.jpg" alt=""
                class="img-fluid mt100">
                <p id="pson">Prensibimiz, işimizi “iyi” yapmak</p>
            </div>
        </section>
        <section id="egitimler">
            <div class="container">
                 <h3>Eğitimler</h3>
                 <div class="owl-carousel owl-theme">
                     <div class="card item" data-merge=1.5>
                         <img src="img/r2.jpg" alt="" class="img-fluid">
                         <h5 class="baslikcard">HTML CSS Eğitimi</h5>
                         <p class="cardp">HTML ve CSS konularını öğrenerek, profesyonel web sayfaları oluşturun!</p>
                     </div>
                     <div class="card item" data-merge=1.5>
                         <img src="img/r2.jpg" alt="" class="img-fluid">
                         <h5 class="baslikcard">Python Eğitimi</h5>
                         <p class="cardp">Python dilini öğrenerek yazılım hayatınızda farklılık yaratın!</p>
                     </div>
                     <div class="card item" data-merge=1.5>
                         <img src="img/r2.jpg" alt="" class="img-fluid">
                         <h5 class="baslikcard">Java Eğitimi</h5>
                         <p class="cardp">Java dilini öğrenerek birçok alanda bilginiz olsun!</p>
                     </div>     
             </div>
            </div>
        </section>
        <section id="ekip">
            <div class="container">
                <center>
             <h3 id="ekiph3">Ekip</h3>
</center>
              <div class="sutun-sol-sag" style="background-color:lightblue;">
                  <img src="img/ekip1.jpg" alt=""  style="width:250px; height:250px;">
                   <a class="ekipisim">
                     Yusuf Gümüş
</a>
                    <p class="ekipp">
                     Web Developer
                    </p>
                    <div class="ekip-ikon">
                       <a href="#"><i class="fa-brands fa-facebook-f social"></i></a>
                       <a href="#"><i class="fa-brands fa-google social"></i></a>
                       <a href="#"><i class="fa-brands fa-twitter social"></i></a>
                    </div>
              </div>
              <div class="sutun-sol-sag" style="background-color:lightblue;">
                  <img src="img/ekip2.jpg" alt=""  style="width:250px; height:250px;">
                   <a class="ekipisim">
                     Ayşe Gümüş
</a>
                    <p class="ekipp">
                     Data Scientist
                    </p>
                    <div class="ekip-ikon">
                       <a href="#"><i class="fa-brands fa-facebook-f social"></i></a>
                       <a href="#"><i class="fa-brands fa-google social"></i></a>
                       <a href="#"><i class="fa-brands fa-twitter social"></i></a>
                    </div>
              </div>
              <div class="sutun-sol-sag" style="background-color:lightblue;">
                  <img src="img/ekip3.jpg" alt=""  style="width:250px; height:250px;">
                   <a class="ekipisim">
                     Zeynep Gümüş
</a>
                    <p class="ekipp">
                    Junior Web Developer
                    </p>
                    <div class="ekip-ikon">
                       <a href="#"><i class="fa-brands fa-facebook-f social"></i></a>
                       <a href="#"><i class="fa-brands fa-google social"></i></a>
                       <a href="#"><i class="fa-brands fa-twitter social"></i></a>
                    </div>
              </div>
            </div>
        </section>
        <section id ="iletişim">
            <div class="container">
                <h3 id="h3iletisim">İletişim</h3>
                <form action="index.php" method="post">
                <div id="iletisimopak">
                    <div id="formgroup">
                        <div id="solform">
                            <input type="text" name="isim" placeholder="Ad Soyad" required class="form-control">
                            <input type="text" name="tel" placeholder="Telefon Numarası" required class="form-control">
                        </div>
                        <div id="sagform">
                        <input type="email" name="mail" placeholder="Email Adresiniz" required class="form-control">
                            <input type="text" name="konu" placeholder="Konu Boşluğu" required class="form-control">
                        </div>
                        <textarea name="mesaj" id="" cols="30" placeholder="Mesajınız" rows="10" required class="form-control"></textarea>
                        <input type="submit" value="Gönder">
                    </div>
                    <div id="adres">
                        <h4 id="adresbaslik">Adres : </h4>
                        <p class="adresp">Paşa Mah.</p>
                        <p class="adresp">Avukat Cad.</p>
                        <p class="adresp">No:120</p>
                        <p class="adresp">0533 582 20 19</p>
                        <p class="adresp">Email : yazılım@akkurt.com</p>
                    </div>
                </div>
                </form>
                <footer>
                    <div id="copyright">2022 Tüm Hakları Saklıdır</div>
                    <div id="socialfooter">
                    <a href="#"><i class="fa-brands fa-facebook-f social"></i></a>
                       <a href="#"><i class="fa-brands fa-google social"></i></a>
                       <a href="#"><i class="fa-brands fa-twitter social"></i></a>
                    </div>
                    <a href="#menu">
                    <i class="fa-solid fa-arrow-up" id="up"></i>
                    </a>
                </footer>
            </div>
        </section>
        <script src="https://code.jquery.com/jquery-
        3.6.0.slim.min.js" 
        integrity="sha256-u7e5khyithlIdTpu22PHhENmPcRdFiHRjhAuHcs05RI=" 
        crossorigin="anonymous">
    </script>
        <script src="owl/owl.carousel.min"></script>
        <script src="owl/script.js"></script>
    </body>
</html>

<?php
include("baglanti.php");
if(isset($_POST["isim"], $_POST["tel"], $_POST["mail"], $_POST["konu"], $_POST["mesaj"]))
{
    $adsoyad=$_POST["isim"];
    $telefon=$_POST["tel"];
    $mail=$_POST["mail"];
    $konu=$_POST["konu"];
    $mesaj=$_POST["mesaj"];

    $ekle="INSERT INTO iletisim(adsoyad,telefon,email,konu,mesaj)
     VALUES ('".$adsoyad."','".$telefon."','".$mail."','".$konu."','".$mesaj."')";
     if($baglan->query($ekle)===TRUE)
     {
         echo "<script>alert('Mesajınız Başarı İle Gönderilmiştir.')</script>";
     }
     else{
         echo "<script>alert('Mesajınız Gönderilirken Hata Oluştu.')</script>";
     }
}
?>